# Build notes

This project targets Minecraft 1.21.1 using Fabric. Fabric's 1.21.1 docs describe Loom/Loader/API as the standard toolchain, and Minecraft 1.20.5+ requires Java 21.

The development environment used for this packaging session has Java 21 but does not have the Fabric/Minecraft Gradle dependencies cached and cannot reach Maven/Gradle distribution hosts, so the final remapped JAR could not be locally compiled in this session. The project files are ready for Gradle to resolve the declared dependencies in a normal networked development environment.
