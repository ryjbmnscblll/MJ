# gptKHD 1.21.1 Combined Feature Set

This source tree combines the previously developed modules into one Fabric 1.21.1 project.

## Included
- gptKHD Chinese ClickGUI/module catalog and adjustable settings
- Auto Enchanted Golden Apple workflow
- StructureFinder-derived Ancient City scanner integration (Cubiomes core)
- Loaded-container enchanted golden apple verification
- Armor-fly controller abstraction with no-firework mode, LAZY/TICK_LEGACY/TICK profiles
- Auto firework refill from shulker boxes stored in Ender Chest
- Auto pickaxe refill/replacement from shulker boxes stored in Ender Chest
- Previous combat/movement/world/render/misc/config module catalog and public-reference setting values

## Important implementation boundary
The special modules contain task state machines and Fabric-facing adapter points. Container interaction, player input, flight state, and item movement must be wired to the Minecraft 1.21.1 client API before these actions occur in-game. The StructureFinder integration distinguishes predicted Ancient City locations from verified loaded containers.

The project targets Minecraft 1.21.1, Fabric, and Java 21.
