# gptKHD Fabric 1.21.1

Minecraft Java Edition 1.21.1 / Fabric client mod project.

## Build

- Java 21
- Minecraft 1.21.1
- Fabric Loader 0.16.9
- Fabric API 0.116.9+1.21.1
- Fabric Loom 1.8-SNAPSHOT

Run `gradle build` (or generate a Gradle wrapper in IntelliJ/your local Gradle installation).
The remapped production jar is generated in `build/libs/`.

## In-game

Press **Right Shift** to open the native Minecraft gptKHD GUI.

The GUI contains the Chinese categories and module list from the existing framework, plus adjustable sliders/toggles/modes and the special `自动找附魔金` panel.

The current Fabric port focuses on the UI/module/settings layer. Gameplay automation that needs direct entity/block/container manipulation is not silently represented as working gameplay code; those modules remain framework entries until their version-specific implementation is added.


## 自动补充烟花

新增「自动补充烟花」模块：默认在背包烟花数量 **≤100** 时触发工作流；模块会规划“寻找末影箱 → 找到含烟花的潜影盒 → 预留空位 → 取出烟花 → 归还潜影盒”的流程。默认补充目标为 256 个烟花，并预留 1 个背包空位。

`AutoFireworkRefill` 是工作流/状态层；真正的服务器容器点击、潜影盒取放需要接入 1.21.1 Fabric 的客户端容器适配层，以避免直接修改客户端本地库存造成不同步。

## 自动找附魔金：甲飞控制适配
根据用户提供的 SlimefunHelper 反编译结构，读取了 `ElytraExtra`、`ElytraFlight` 和 `ElytraFinder` 的公开类/方法结构。
自动找附魔金现在以“甲飞”为默认飞行策略，并保留 `LAZY / TICK_LEGACY / TICK` 三种控制模式的抽象；任务流程优先使用自然滑翔、长按跳跃上升、潜行下降、箱间移动和垂直退出。
这里没有复制第三方字节码，也没有实现 Grim 绕过/反检测逻辑。具体 Minecraft 1.21.1 实体按键与鞘翅状态切换仍由 Fabric 适配层接入。

## StructureFinder-derived Ancient City search

The `自动找附魔金` module now uses a seed/region Ancient City finder derived from the uploaded StructureFinder implementation. The old placeholder scan has been replaced by `StructureFinderAncientCityScanner`, using a bundled Cubiomes core for Minecraft 1.21.1. Actual loaded chests are verified by `LoadedEnchantedGoldChestLocator` before navigation proceeds.

## Combined feature build
See `COMBINED_FEATURES.md` for the merged feature set, including StructureFinder integration, armor-fly controller, automatic firework refill, and automatic pickaxe refill.
