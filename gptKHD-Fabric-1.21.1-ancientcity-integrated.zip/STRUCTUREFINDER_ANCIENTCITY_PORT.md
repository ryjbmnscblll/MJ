# StructureFinder 古城模块移植

参考上传的 `StructureFinder-1.21.11-Meteor85-v3.jar` 中的：
- `AncientCityModule`
- `GoldenAppleChestScanner`
- `PreciseAppleEngine`
- `PreOpenLootSeedCache`
- `RangeConfig`
- `GoldenAppleSetting`

在 gptKHD Fabric 1.21.1 中新增 `AncientCityModule` 总控，把此前的：
古城定位、附魔金箱验证、甲飞、无烟花、目标箱路线、返回入口、直线上升、烟花补充、镐子补充统一到古城模块。

Meteor 的 Module/Event API 没有直接复制进 Fabric；实际 Minecraft 输入、实体飞行和容器交互仍由 Fabric 适配层负责。
