package com.gptkhd.client.config;

import com.gptkhd.client.module.ModuleRegistry;
import java.nio.file.Files;
import java.nio.file.Path;

public final class ConfigManager {
    private final Path directory = Path.of("config", "gptKHD");

    public void save(ModuleRegistry registry) {
        // 预留 JSON/TOML 序列化。
    }

    public void load(ModuleRegistry registry) {
        // 预留 JSON/TOML 反序列化。
    }

    public void reset(ModuleRegistry registry) {
        // 恢复默认设置。
    }

    public Path directory() {
        return directory;
    }
}
