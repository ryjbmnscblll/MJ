package com.gptkhd.client.setting;

import java.util.List;

public final class ModeSetting extends Setting<String> {
    private final List<String> modes;

    public ModeSetting(String name, String value, List<String> modes) {
        super(name, value);
        this.modes = List.copyOf(modes);
    }

    public List<String> modes() {
        return modes;
    }
}
