package com.gptkhd.client.setting;

import java.util.List;

public record SettingSpec(
        String name,
        Type type,
        double value,
        double min,
        double max,
        double step,
        List<String> modes
) {
    public enum Type { SLIDER, TOGGLE, MODE }

    public static SettingSpec slider(String name, double value, double min, double max, double step) {
        return new SettingSpec(name, Type.SLIDER, value, min, max, step, List.of());
    }

    public static SettingSpec toggle(String name, boolean value) {
        return new SettingSpec(name, Type.TOGGLE, value ? 1 : 0, 0, 1, 1, List.of());
    }

    public static SettingSpec mode(String name, String value, String... modes) {
        return new SettingSpec(name, Type.MODE, 0, 0, 0, 0,
                List.of(modes));
    }
}
