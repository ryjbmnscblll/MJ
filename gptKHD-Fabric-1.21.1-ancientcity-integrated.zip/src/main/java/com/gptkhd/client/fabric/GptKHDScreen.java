package com.gptkhd.client.fabric;

import com.gptkhd.client.module.ModuleCategory;
import com.gptkhd.client.module.ModuleRegistry;
import com.gptkhd.client.module.ModuleSpec;
import com.gptkhd.client.setting.SettingSpec;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** gptKHD native Minecraft screen for 1.21.1. */
public final class GptKHDScreen extends Screen {
    private static final int BG = 0xFF080B18;
    private static final int PANEL = 0xFF101632;
    private static final int PANEL_2 = 0xFF171E40;
    private static final int ACCENT = 0xFF754BFF;
    private static final int ACCENT_2 = 0xFF9A7BFF;
    private static final int TEXT = 0xFFF4F1FF;
    private static final int MUTED = 0xFF9A9AB6;
    private static final int LINE = 0xFF302B68;

    private final ModuleRegistry registry = GptKHD.modules();
    private ModuleCategory category = ModuleCategory.COMBAT;
    private ModuleSpec selected;
    private int moduleScroll;
    private int settingScroll;
    private String search = "";
    private boolean searchMode;
    private boolean draggingSlider;
    private SettingSpec draggingSetting;
    private final Map<String, Boolean> enabled = new HashMap<>();
    private final Map<String, Map<String, Object>> values = new HashMap<>();

    public GptKHDScreen() {
        super(Text.literal("gptKHD"));
        selected = registry.byCategory(category).stream().findFirst().orElse(null);
    }

    @Override
    protected void init() {
        moduleScroll = 0;
        settingScroll = 0;
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.fill(0, 0, width, height, BG);
        drawTop(ctx);
        drawSidebar(ctx, mouseX, mouseY);
        drawModules(ctx, mouseX, mouseY);
        drawDetails(ctx, mouseX, mouseY);
        super.render(ctx, mouseX, mouseY, delta);
    }

    private void drawTop(DrawContext c) {
        c.fill(0, 0, width, 74, PANEL);
        c.fill(0, 73, width, 75, ACCENT);
        c.drawTextWithShadow(textRenderer, Text.literal("gptKHD"), 24, 16, TEXT);
        c.drawTextWithShadow(textRenderer, Text.literal("更好的游戏 · 更强的你"), 26, 42, MUTED);
        c.drawTextWithShadow(textRenderer, Text.literal("FPS  •  " + fps() + "    延迟  •  --ms    玩家  •  --"), width - 285, 23, MUTED);
        c.drawTextWithShadow(textRenderer, Text.literal("右Shift  打开/关闭"), width - 165, 45, ACCENT_2);
    }

    private int fps() {
        return client == null ? 0 : client.getCurrentFps();
    }

    private void drawSidebar(DrawContext c, int mx, int my) {
        int x = 14, y = 90, w = 122;
        c.fill(x, y, x + w, height - 16, PANEL);
        int i = 0;
        for (ModuleCategory cat : ModuleCategory.values()) {
            int by = y + 10 + i * 43;
            boolean hover = mx >= x + 7 && mx <= x + w - 7 && my >= by && my <= by + 34;
            boolean active = cat == category;
            c.fill(x + 7, by, x + w - 7, by + 34, active ? ACCENT : (hover ? PANEL_2 : PANEL));
            c.drawTextWithShadow(textRenderer, Text.literal(cat.displayName()), x + 20, by + 11, TEXT);
            i++;
        }
    }

    private void drawModules(DrawContext c, int mx, int my) {
        int x = 148, y = 90, w = 390, h = height - 106;
        c.fill(x, y, x + w, y + h, PANEL);
        c.drawTextWithShadow(textRenderer, Text.literal(category.displayName()), x + 16, y + 14, TEXT);
        c.drawTextWithShadow(textRenderer, Text.literal("模块列表"), x + 16, y + 34, MUTED);

        List<ModuleSpec> list = registry.byCategory(category).stream()
                .filter(m -> search.isBlank() || m.name().contains(search))
                .toList();
        int rowY = y + 62 - moduleScroll;
        for (ModuleSpec spec : list) {
            if (rowY + 48 < y + 52 || rowY > y + h) { rowY += 54; continue; }
            boolean active = enabled.getOrDefault(spec.name(), false);
            boolean hover = mx >= x + 10 && mx <= x + w - 10 && my >= rowY && my <= rowY + 46;
            c.fill(x + 10, rowY, x + w - 10, rowY + 46, active ? 0xFF25205B : (hover ? PANEL_2 : 0xFF131A38));
            c.fill(x + 10, rowY, x + 13, rowY + 46, active ? ACCENT : LINE);
            c.drawTextWithShadow(textRenderer, Text.literal(spec.name()), x + 22, rowY + 8, TEXT);
            c.drawTextWithShadow(textRenderer, Text.literal(shorten(spec.description(), 38)), x + 22, rowY + 27, MUTED);
            c.drawTextWithShadow(textRenderer, Text.literal(active ? "● 开启" : "○ 关闭"), x + w - 72, rowY + 17, active ? ACCENT_2 : MUTED);
            rowY += 54;
        }
        if (selected != null) {
            c.drawTextWithShadow(textRenderer, Text.literal("当前：" + selected.name()), x + 16, y + h - 22, ACCENT_2);
        }
    }

    private String shorten(String s, int max) {
        return s.length() <= max ? s : s.substring(0, Math.max(0, max - 1)) + "…";
    }

    private void drawDetails(DrawContext c, int mx, int my) {
        int x = 548, y = 90, w = width - x - 14, h = height - 106;
        c.fill(x, y, x + w, y + h, PANEL);
        if (selected == null) return;
        c.drawTextWithShadow(textRenderer, Text.literal(selected.name()), x + 20, y + 18, TEXT);
        c.drawTextWithShadow(textRenderer, Text.literal(selected.description()), x + 20, y + 39, MUTED);
        c.drawTextWithShadow(textRenderer, Text.literal("设置"), x + 20, y + 68, ACCENT_2);

        int sy = y + 92 - settingScroll;
        List<SettingSpec> settings = selected.adjustableSettings();
        for (SettingSpec s : settings) {
            if (sy + 55 >= y + 80 && sy <= y + h - 18) drawSetting(c, x + 20, sy, w - 40, s, mx, my);
            sy += s.type() == SettingSpec.Type.SLIDER ? 66 : 48;
        }
        if (selected.name().equals("自动找附魔金")) {
            int py = y + h - 84;
            c.fill(x + 18, py, x + w - 18, py + 66, 0xFF151A38);
            c.drawTextWithShadow(textRenderer, Text.literal("任务状态"), x + 30, py + 10, ACCENT_2);
            c.drawTextWithShadow(textRenderer, Text.literal(enabled.getOrDefault(selected.name(), false) ? "扫描古城 → 标记箱子 → 规划路线" : "空闲"), x + 30, py + 34, TEXT);
        }
    }

    private void drawSetting(DrawContext c, int x, int y, int w, SettingSpec s, int mx, int my) {
        c.drawTextWithShadow(textRenderer, Text.literal(s.name()), x, y, TEXT);
        if (s.type() == SettingSpec.Type.TOGGLE) {
            boolean on = boolValue(s);
            c.fill(x + w - 54, y - 4, x + w, y + 18, on ? ACCENT : LINE);
            c.drawTextWithShadow(textRenderer, Text.literal(on ? "开" : "关"), x + w - 39, y + 2, TEXT);
        } else if (s.type() == SettingSpec.Type.MODE) {
            Object v = value(s);
            c.fill(x + w - 150, y - 5, x + w, y + 20, PANEL_2);
            c.drawTextWithShadow(textRenderer, Text.literal(String.valueOf(v)), x + w - 137, y + 2, ACCENT_2);
        } else {
            double v = numberValue(s);
            int bx = x, by = y + 22, bw = w;
            c.fill(bx, by, bx + bw, by + 5, LINE);
            double pct = (v - s.min()) / (s.max() - s.min());
            int knob = bx + (int)(Math.max(0, Math.min(1, pct)) * bw);
            c.fill(bx, by, knob, by + 5, ACCENT);
            c.fill(knob - 4, by - 3, knob + 4, by + 13, ACCENT_2);
            c.drawTextWithShadow(textRenderer, Text.literal(format(v) + valueSuffix(s)), x + w - 80, y, ACCENT_2);
        }
    }

    private String valueSuffix(SettingSpec s) {
        return s.name().contains("速度") && s.name().contains("攻击") ? " CPS" : "";
    }

    private String format(double v) {
        return Math.abs(v - Math.rint(v)) < 0.0001 ? Integer.toString((int)Math.rint(v)) : String.format(java.util.Locale.ROOT, "%.2f", v);
    }

    private Object value(SettingSpec s) {
        return values.computeIfAbsent(selected.name(), k -> new LinkedHashMap<>())
                .computeIfAbsent(s.name(), k -> s.type() == SettingSpec.Type.SLIDER ? s.value() : s.type() == SettingSpec.Type.TOGGLE ? s.value() > 0.5 : s.modes().get(0));
    }

    private boolean boolValue(SettingSpec s) { return Boolean.TRUE.equals(value(s)); }
    private double numberValue(SettingSpec s) { return ((Number)value(s)).doubleValue(); }

    private void setSlider(SettingSpec s, double v) {
        double step = s.step();
        double rounded = Math.round(v / step) * step;
        values.computeIfAbsent(selected.name(), k -> new LinkedHashMap<>()).put(s.name(), Math.max(s.min(), Math.min(s.max(), rounded)));
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button != GLFW.GLFW_MOUSE_BUTTON_1) return super.mouseClicked(mouseX, mouseY, button);
        // categories
        int sx = 14, sy = 100;
        for (ModuleCategory cat : ModuleCategory.values()) {
            int by = sy + (cat.ordinal() * 43);
            if (mouseX >= sx + 7 && mouseX <= sx + 115 && mouseY >= by && mouseY <= by + 34) {
                category = cat;
                selected = registry.byCategory(category).stream().findFirst().orElse(null);
                moduleScroll = settingScroll = 0;
                return true;
            }
        }
        // module cards
        int x = 148, y = 152 - moduleScroll;
        for (ModuleSpec spec : registry.byCategory(category).stream().filter(m -> search.isBlank() || m.name().contains(search)).toList()) {
            if (mouseX >= x + 10 && mouseX <= x + 380 && mouseY >= y && mouseY <= y + 46) {
                selected = spec;
                if (mouseX > x + 315) enabled.put(spec.name(), !enabled.getOrDefault(spec.name(), false));
                else settingScroll = 0;
                return true;
            }
            y += 54;
        }
        // settings
        if (selected != null) {
            int dx = 568, dw = width - 588, yy = 182 - settingScroll;
            for (SettingSpec s : selected.adjustableSettings()) {
                int sh = s.type() == SettingSpec.Type.SLIDER ? 66 : 48;
                if (mouseY >= yy - 4 && mouseY <= yy + sh - 8 && mouseX >= dx && mouseX <= dx + dw) {
                    if (s.type() == SettingSpec.Type.TOGGLE) {
                        values.computeIfAbsent(selected.name(), k -> new LinkedHashMap<>()).put(s.name(), !boolValue(s));
                    } else if (s.type() == SettingSpec.Type.MODE) {
                        List<String> modes = s.modes();
                        int idx = modes.indexOf(String.valueOf(value(s)));
                        values.computeIfAbsent(selected.name(), k -> new LinkedHashMap<>()).put(s.name(), modes.get((idx + 1) % modes.size()));
                    } else {
                        draggingSlider = true; draggingSetting = s; updateSlider(mouseX, dx, dw, s);
                    }
                    return true;
                }
                yy += sh;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    private void updateSlider(double mouseX, int x, int w, SettingSpec s) {
        double pct = Math.max(0, Math.min(1, (mouseX - x) / (double)w));
        setSlider(s, s.min() + pct * (s.max() - s.min()));
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (draggingSlider && draggingSetting != null) {
            updateSlider(mouseX, 568, width - 588, draggingSetting);
            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        draggingSlider = false;
        draggingSetting = null;
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (mouseX >= 148 && mouseX < 538) moduleScroll = Math.max(0, moduleScroll - (int)(verticalAmount * 30));
        if (mouseX >= 548) settingScroll = Math.max(0, settingScroll - (int)(verticalAmount * 30));
        return true;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_ESCAPE) { close(); return true; }
        if (keyCode == GLFW.GLFW_KEY_K && hasControlDown()) { searchMode = true; return true; }
        if (searchMode) {
            if (keyCode == GLFW.GLFW_KEY_BACKSPACE && !search.isEmpty()) search = search.substring(0, search.length() - 1);
            else if (keyCode == GLFW.GLFW_KEY_ENTER) searchMode = false;
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        if (searchMode && !Character.isISOControl(chr)) { search += chr; return true; }
        return super.charTyped(chr, modifiers);
    }

    @Override
    public boolean shouldPause() { return false; }
}
