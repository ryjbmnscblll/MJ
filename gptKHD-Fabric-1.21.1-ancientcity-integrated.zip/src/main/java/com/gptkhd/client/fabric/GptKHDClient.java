package com.gptkhd.client.fabric;

import com.gptkhd.client.GptKHD;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public final class GptKHDClient implements ClientModInitializer {
    public static final String MOD_ID = "gptkhd";
    private static KeyBinding openGui;

    @Override
    public void onInitializeClient() {
        GptKHD.init();
        openGui = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.gptkhd.open_gui",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "category.gptkhd"
        ));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openGui.wasPressed()) {
                if (client.currentScreen == null) {
                    client.setScreen(new GptKHDScreen());
                }
            }
        });
    }
}
