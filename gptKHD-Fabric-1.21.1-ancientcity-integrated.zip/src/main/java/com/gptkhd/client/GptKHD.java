package com.gptkhd.client;

import com.gptkhd.client.module.ModuleRegistry;
import com.gptkhd.client.module.special.AutoEnchantedGold;

public final class GptKHD {
    public static final String NAME = "gptKHD";
    public static final String VERSION = "0.2.0";

    private static ModuleRegistry modules;
    private static AutoEnchantedGold autoEnchantedGold;

    private GptKHD() {}

    public static void init() {
        modules = new ModuleRegistry();
        modules.registerAll();
        autoEnchantedGold = new AutoEnchantedGold();
    }

    public static ModuleRegistry modules() {
        return modules;
    }

    public static AutoEnchantedGold autoEnchantedGold() {
        return autoEnchantedGold;
    }
}
