package com.gptkhd.client.module.special;

import com.gptkhd.client.module.Module;
import com.gptkhd.client.module.ModuleCategory;
import com.gptkhd.client.setting.BooleanSetting;
import com.gptkhd.client.setting.ModeSetting;
import com.gptkhd.client.setting.NumberSetting;
import java.util.List;

/**
 * 自动找附魔金的 UI/任务状态机。
 * 游戏世界扫描、飞行、容器交互等具体适配逻辑留给版本适配层。
 */
public final class AutoEnchantedGold extends Module {
    public enum State {
        空闲,
        扫描古城,
        无烟花鞘翅下降,
        长按空格上升,
        对准附魔金上方,
        下蹲下降,
        扫描目标箱子,
        处理箱子,
        飞往下一个箱子,
        古城箱子完成,
        直线上升出口,
        前往下一个古城,
        完成
    }

    public final NumberSetting scanRange =
            add(new NumberSetting("扫描半径", 5000, 500, 10000, 100));
    public final NumberSetting cityRange =
            add(new NumberSetting("古城扫描范围", 200, 32, 512, 8));
    public final BooleanSetting requireElytra =
            add(new BooleanSetting("需要鞘翅", true));
    public final BooleanSetting liquidCheck =
            add(new BooleanSetting("液体安全检查", true));
    public final BooleanSetting straightMine =
            add(new BooleanSetting("直线下挖", true));
    public final BooleanSetting returnRoute =
            add(new BooleanSetting("返回原路", true));
    public final BooleanSetting noFireworkFlight =
            add(new BooleanSetting("无烟花鞘翅飞行", true));
    public final BooleanSetting holdJump =
            add(new BooleanSetting("长按空格升高", true));
    public final BooleanSetting crouchDescent =
            add(new BooleanSetting("下蹲下降搜索", true));
    public final BooleanSetting returnToEntry =
            add(new BooleanSetting("返回原挖掘位置", true));
    public final BooleanSetting verticalExit =
            add(new BooleanSetting("直线上升出古城", true));
    public final NumberSetting targetHeight =
            add(new NumberSetting("目标上方高度", 12, 3, 40, 1));
    public final ModeSetting flightMode =
            add(new ModeSetting("飞行方式", "甲飞",
                    List.of("甲飞", "普通鞘翅")));
    public final ModeSetting armorFlyMode =
            add(new ModeSetting("甲飞控制模式", "TICK",
                    List.of("LAZY", "TICK_LEGACY", "TICK")));
    public final BooleanSetting noFireworkBoost =
            add(new BooleanSetting("禁止烟花推进", true));
    public final ModeSetting routeMode =
            add(new ModeSetting("路线模式", "最近优先",
                    List.of("最近优先", "最短路线", "目标密度")));

    private State state = State.空闲;
    private final ArmorFlyController armorFly = new ArmorFlyController();
    private StructureFinderAncientCityScanner structureFinder;
    private final LoadedEnchantedGoldChestLocator chestLocator = new LoadedEnchantedGoldChestLocator();
    private List<StructureFinderAncientCityScanner.City> predictedCities = List.of();
    private List<LoadedEnchantedGoldChestLocator.ChestTarget> verifiedChests = List.of();

    public AutoEnchantedGold() {
        super("自动找附魔金", ModuleCategory.GENERATOR,
                "扫描古城并建立附魔金箱子目标列表");
    }

    @Override
    protected void onEnable() {
        state = State.扫描古城;
        predictedCities = List.of();
        verifiedChests = List.of();
        armorFly.setMode(parseArmorMode(armorFlyMode.get()));
        armorFly.startGlide();
    }

    @Override
    protected void onDisable() {
        state = State.空闲;
        armorFly.stopGlide();
    }

    public State state() {
        return state;
    }

    /** Replace the old placeholder scan with the StructureFinder-derived seed scan. */
    public List<StructureFinderAncientCityScanner.City> findAncientCities(long seed, int playerX, int playerZ) {
        if (structureFinder == null) structureFinder = new StructureFinderAncientCityScanner();
        predictedCities = structureFinder.findNearest(seed, playerX, playerZ, (int) scanRange.get(), 20);
        return predictedCities;
    }

    /** Verify actual loaded containers around the selected city before navigation. */
    public List<LoadedEnchantedGoldChestLocator.ChestTarget> findLoadedEnchantedGoldChests(
            net.minecraft.client.world.ClientWorld world, int cityX, int cityZ) {
        verifiedChests = chestLocator.scan(world, cityX, cityZ, (int) cityRange.get());
        return verifiedChests;
    }

    public List<StructureFinderAncientCityScanner.City> predictedCities() {
        return List.copyOf(predictedCities);
    }

    public List<LoadedEnchantedGoldChestLocator.ChestTarget> verifiedChests() {
        return List.copyOf(verifiedChests);
    }

    /**
     * 自动找附魔金的任务状态推进器。
     *
     * 设计目标：不主动消耗烟花。到达古城后从较高位置滑翔下降，
     * 通过持续上升/下降控制在目标箱子附近定位；拿完当前箱子后直接滑翔
     * 到下一个目标。一个古城的目标全部处理完，再回到入口/原挖掘位置
     * 垂直上升离开，然后继续下一个古城。
     *
     * 实际按键、玩家移动和容器交互由 Fabric 1.21.1 适配层执行。
     */
    public void advance(boolean cityFound,
                        boolean entryReached,
                        boolean aboveTarget,
                        boolean landedAtTarget,
                        boolean chestFound,
                        boolean looted,
                        boolean nextChestFound,
                        boolean cityFinished,
                        boolean exitReached,
                        boolean allFinished) {
        armorFly.setMode(parseArmorMode(armorFlyMode.get()));

        switch (state) {
            case 扫描古城 -> {
                armorFly.stopGlide();
                if (cityFound) {
                    armorFly.startGlide();
                    state = State.无烟花鞘翅下降;
                }
            }
            case 无烟花鞘翅下降 -> {
                // 不主动使用烟花：保持甲飞/滑翔，利用自然高度差进入古城。
                armorFly.holdJump(false);
                armorFly.sneakDown(false);
                if (entryReached) state = State.长按空格上升;
            }
            case 长按空格上升 -> {
                armorFly.holdJump(true);
                if (aboveTarget) {
                    armorFly.holdJump(false);
                    state = State.对准附魔金上方;
                }
            }
            case 对准附魔金上方 -> {
                if (landedAtTarget) state = State.下蹲下降;
            }
            case 下蹲下降 -> {
                armorFly.sneakDown(crouchDescent.get());
                state = State.扫描目标箱子;
            }
            case 扫描目标箱子 -> {
                armorFly.sneakDown(false);
                if (chestFound) state = State.处理箱子;
            }
            case 处理箱子 -> {
                if (looted) {
                    state = nextChestFound ? State.飞往下一个箱子 : State.古城箱子完成;
                }
            }
            case 飞往下一个箱子 -> {
                armorFly.startGlide();
                state = State.扫描目标箱子;
            }
            case 古城箱子完成 -> {
                state = returnToEntry.get() ? State.直线上升出口 : State.前往下一个古城;
            }
            case 直线上升出口 -> {
                armorFly.holdJump(true);
                if (exitReached) {
                    armorFly.holdJump(false);
                    state = State.前往下一个古城;
                }
            }
            case 前往下一个古城 -> {
                state = allFinished ? State.完成 : State.扫描古城;
            }
            case 空闲, 完成 -> {
                armorFly.stopGlide();
            }
        }
    }

    private ArmorFlyController.Mode parseArmorMode(String value) {
        try {
            return ArmorFlyController.Mode.valueOf(value);
        } catch (Exception ignored) {
            return ArmorFlyController.Mode.TICK;
        }
    }

    public ArmorFlyController armorFlyController() {
        return armorFly;
    }


}
