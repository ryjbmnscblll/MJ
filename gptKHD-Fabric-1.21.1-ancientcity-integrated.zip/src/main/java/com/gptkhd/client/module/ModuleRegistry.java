package com.gptkhd.client.module;

import com.gptkhd.client.module.catalog.*;
import java.util.ArrayList;
import java.util.List;

public final class ModuleRegistry {
    private final List<ModuleSpec> modules = new ArrayList<>();

    public void registerAll() {
        modules.clear();
        modules.addAll(CombatModules.all());
        modules.addAll(MovementModules.all());
        modules.addAll(WorldModules.all());
        modules.addAll(RenderModules.all());
        modules.addAll(MiscModules.all());
        modules.addAll(ConfigModules.all());
        modules.addAll(GeneratorModules.all());
    }

    public List<ModuleSpec> all() {
        return List.copyOf(modules);
    }

    public List<ModuleSpec> byCategory(ModuleCategory category) {
        return modules.stream()
                .filter(m -> m.category() == category)
                .toList();
    }

    public ModuleSpec find(String name) {
        return modules.stream()
                .filter(m -> m.name().equals(name))
                .findFirst()
                .orElse(null);
    }
}
