package com.gptkhd.client.module;

public enum ModuleCategory {
    COMBAT("战斗"),
    MOVEMENT("移动"),
    WORLD("世界"),
    RENDER("视觉"),
    MISC("其他"),
    CONFIG("配置"),
    GENERATOR("生成");

    private final String displayName;

    ModuleCategory(String displayName) {
        this.displayName = displayName;
    }

    public String displayName() {
        return displayName;
    }
}
