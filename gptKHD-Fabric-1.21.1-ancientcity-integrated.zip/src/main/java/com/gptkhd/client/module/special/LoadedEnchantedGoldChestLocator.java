package com.gptkhd.client.module.special;

import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.chunk.WorldChunk;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Verifies the predicted area against actually loaded chests.
 *
 * StructureFinder can predict Ancient City placement from a seed. This
 * verifier deliberately checks real client-world containers before the
 * movement task commits to a chest, so the navigation layer does not assume
 * a predicted chest is present when chunks/loot are not loaded.
 */
public final class LoadedEnchantedGoldChestLocator {
    public record ChestTarget(BlockPos pos, int enchantedGoldenApples) {}

    public List<ChestTarget> scan(ClientWorld world, int centerX, int centerZ, int radius) {
        int minChunkX = Math.floorDiv(centerX - radius, 16);
        int maxChunkX = Math.floorDiv(centerX + radius, 16);
        int minChunkZ = Math.floorDiv(centerZ - radius, 16);
        int maxChunkZ = Math.floorDiv(centerZ + radius, 16);
        long radiusSq = (long) radius * radius;
        List<ChestTarget> found = new ArrayList<>();

        for (int cx = minChunkX; cx <= maxChunkX; cx++) {
            for (int cz = minChunkZ; cz <= maxChunkZ; cz++) {
                WorldChunk chunk;
                try {
                    chunk = world.getChunk(cx, cz);
                } catch (RuntimeException ignored) {
                    continue;
                }
                for (BlockEntity be : chunk.getBlockEntities().values()) {
                    if (!(be instanceof ChestBlockEntity chest)) continue;
                    BlockPos p = chest.getPos();
                    long dx = (long) p.getX() - centerX;
                    long dz = (long) p.getZ() - centerZ;
                    if (dx * dx + dz * dz > radiusSq) continue;

                    int count = 0;
                    for (int slot = 0; slot < chest.size(); slot++) {
                        ItemStack stack = chest.getStack(slot);
                        if (stack.isOf(Items.ENCHANTED_GOLDEN_APPLE)) count += stack.getCount();
                    }
                    if (count > 0) found.add(new ChestTarget(p.toImmutable(), count));
                }
            }
        }

        found.sort(Comparator.comparingDouble(t -> t.pos().getSquaredDistance(centerX, t.pos().getY(), centerZ)));
        return List.copyOf(found);
    }
}
