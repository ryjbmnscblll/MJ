package com.gptkhd.client.module.special;

import com.gptkhd.client.module.Module;
import com.gptkhd.client.module.ModuleCategory;
import com.gptkhd.client.setting.BooleanSetting;
import com.gptkhd.client.setting.NumberSetting;

/**
 * 自动补充/更换镐子任务状态机。
 *
 * 默认行为：当当前使用中的镐子剩余耐久百分比低于或等于阈值时，
 * 寻找末影箱 -> 找到装有镐子的潜影盒 -> 取出耐久接近满值的镐子
 * -> 替换当前镐子 -> 将潜影盒放回末影箱。
 * 实际打开容器、读取潜影盒组件和移动物品由 Fabric 1.21.1 适配层执行。
 */
public final class AutoPickaxeRefill extends Module {
    public enum State {
        空闲,
        检查镐子耐久,
        寻找末影箱,
        打开末影箱,
        寻找镐子潜影盒,
        取出潜影盒,
        检查备用镐子,
        取出满耐久镐子,
        替换镐子,
        放回潜影盒,
        关闭末影箱,
        完成,
        未找到材料
    }

    public final NumberSetting durabilityThreshold =
            add(new NumberSetting("触发耐久百分比", 10, 1, 50, 1));
    public final NumberSetting minimumReplacementDurability =
            add(new NumberSetting("备用镐最低耐久百分比", 95, 50, 100, 1));
    public final NumberSetting operationDelay =
            add(new NumberSetting("操作间隔", 5, 1, 40, 1));
    public final BooleanSetting autoFindEnderChest =
            add(new BooleanSetting("自动寻找末影箱", true));
    public final BooleanSetting onlyPickaxes =
            add(new BooleanSetting("只取镐子", true));
    public final BooleanSetting returnShulker =
            add(new BooleanSetting("归还潜影盒", true));
    public final BooleanSetting keepInventorySlot =
            add(new BooleanSetting("预留背包空位", true));
    public final BooleanSetting notifyMissing =
            add(new BooleanSetting("找不到备用镐时通知", true));

    private State state = State.空闲;

    public AutoPickaxeRefill() {
        super("自动补充镐子", ModuleCategory.GENERATOR,
                "镐子耐久不足时从末影箱中的潜影盒自动更换备用镐子");
    }

    @Override
    protected void onEnable() {
        state = State.检查镐子耐久;
    }

    @Override
    protected void onDisable() {
        state = State.空闲;
    }

    public State state() {
        return state;
    }

    /**
     * 由 Fabric 1.21.1 适配层每个客户端 tick/事务阶段推进。
     * 参数代表适配层已经完成的实际游戏动作结果。
     */
    public void advance(boolean pickaxeLowDurability,
                        boolean enderChestFound,
                        boolean enderChestOpened,
                        boolean pickaxeShulkerFound,
                        boolean shulkerTaken,
                        boolean replacementPickaxeFound,
                        boolean replacementTaken,
                        boolean replaced,
                        boolean shulkerReturned,
                        boolean chestClosed) {
        switch (state) {
            case 检查镐子耐久 -> {
                if (pickaxeLowDurability) {
                    state = autoFindEnderChest.get() ? State.寻找末影箱 : State.未找到材料;
                }
            }
            case 寻找末影箱 -> {
                if (enderChestFound) state = State.打开末影箱;
            }
            case 打开末影箱 -> {
                if (enderChestOpened) state = State.寻找镐子潜影盒;
            }
            case 寻找镐子潜影盒 -> {
                if (pickaxeShulkerFound) state = State.取出潜影盒;
                else state = State.未找到材料;
            }
            case 取出潜影盒 -> {
                if (shulkerTaken) state = State.检查备用镐子;
            }
            case 检查备用镐子 -> {
                state = replacementPickaxeFound ? State.取出满耐久镐子 : State.未找到材料;
            }
            case 取出满耐久镐子 -> {
                if (replacementTaken) state = State.替换镐子;
            }
            case 替换镐子 -> {
                if (replaced) state = returnShulker.get() ? State.放回潜影盒 : State.关闭末影箱;
            }
            case 放回潜影盒 -> {
                if (shulkerReturned) state = State.关闭末影箱;
            }
            case 关闭末影箱 -> {
                if (chestClosed) state = State.完成;
            }
            case 完成, 未找到材料 -> { }
            case 空闲 -> { }
        }
    }

    public void reset() {
        state = State.检查镐子耐久;
    }
}
