package com.gptkhd.client.module;

import com.gptkhd.client.setting.SettingSpec;
import java.util.ArrayList;
import java.util.List;

public final class ModuleSettingsCatalog {
    private ModuleSettingsCatalog() {}

    public static List<SettingSpec> settings(ModuleSpec module) {
        String n = module.name();
        List<SettingSpec> s = new ArrayList<>();

        // Combat: values are based on public client documentation/examples.
        if (n.equals("杀戮光环")) {
            s.add(SettingSpec.slider("攻击范围", 5.0, 1.0, 10.0, 0.05));
            s.add(SettingSpec.slider("攻击速度", 0.0, 0.0, 20.0, 0.1)); // 0 = cooldown
            s.add(SettingSpec.slider("FOV", 360, 30, 360, 10));
            s.add(SettingSpec.slider("速度随机", 100, 0, 1000, 50));
            s.add(SettingSpec.mode("目标优先级", "角度", "距离", "角度", "生命值"));
            s.add(SettingSpec.toggle("仅玩家", true));
            s.add(SettingSpec.toggle("穿墙目标", false));
            return s;
        }

        if (n.equals("水晶光环")) {
            s.add(SettingSpec.slider("放置范围", 4.5, 1.0, 6.0, 0.05));
            s.add(SettingSpec.slider("破坏范围", 4.5, 1.0, 6.0, 0.05));
            s.add(SettingSpec.slider("放置延迟", 0, 0, 1000, 10));
            s.add(SettingSpec.slider("破坏延迟", 0, 0, 1000, 10));
            s.add(SettingSpec.slider("最大自身伤害", 2.0, 0, 10, 0.1));
            s.add(SettingSpec.slider("最低目标伤害", 3.0, 0, 10, 0.1));
            s.add(SettingSpec.toggle("自动放置", true));
            s.add(SettingSpec.toggle("自动破坏", true));
            return s;
        }

        if (n.equals("长矛光环") || n.equals("自动攻击")) {
            s.add(SettingSpec.slider("攻击范围", 4.5, 1, 10, 0.1));
            s.add(SettingSpec.slider("攻击间隔", 100, 0, 1000, 10));
            s.add(SettingSpec.mode("目标模式", "最近", "最近", "角度", "生命值"));
            return s;
        }

        if (n.equals("目标选择") || n.equals("攻击辅助") || n.equals("自动连击")) {
            s.add(SettingSpec.slider("选择范围", 4.5, 1, 10, 0.1));
            s.add(SettingSpec.mode("优先目标", "最近", "最近", "生命值", "角度"));
            s.add(SettingSpec.toggle("仅玩家", true));
            return s;
        }

        // Movement
        if (n.equals("速度")) {
            s.add(SettingSpec.slider("速度倍率", 1.0, 0.1, 3.0, 0.05));
            s.add(SettingSpec.toggle("自动跳跃", true));
            s.add(SettingSpec.mode("模式", "普通", "普通", "跳跃", "自定义"));
            return s;
        }

        if (n.equals("飞行")) {
            s.add(SettingSpec.slider("水平速度", 1.0, 0.1, 5.0, 0.1));
            s.add(SettingSpec.slider("垂直速度", 1.0, 0.1, 5.0, 0.1));
            s.add(SettingSpec.mode("模式", "普通", "普通", "漂浮", "自定义"));
            return s;
        }

        if (n.equals("跳跃增强") || n.equals("长跳")) {
            s.add(SettingSpec.slider("跳跃倍率", 1.0, 0.1, 4.0, 0.05));
            s.add(SettingSpec.slider("水平倍率", 1.0, 0.1, 4.0, 0.05));
            return s;
        }

        if (n.equals("传送") || n.equals("瞬移")) {
            s.add(SettingSpec.slider("距离", 5.0, 1, 100, 1));
            s.add(SettingSpec.slider("延迟", 250, 0, 2000, 10));
            return s;
        }

        // World / Render
        if (n.equals("X射线") || n.equals("古城追踪") || n.equals("要塞追踪") ||
                n.equals("矿洞追踪") || n.equals("地形标记")) {
            s.add(SettingSpec.slider("扫描范围", 128, 16, 512, 8));
            s.add(SettingSpec.toggle("显示标记", true));
            return s;
        }

        if (n.equals("自动挖矿") || n.equals("快速挖掘") || n.equals("自动采集")) {
            s.add(SettingSpec.slider("范围", 6, 1, 32, 1));
            s.add(SettingSpec.slider("操作延迟", 100, 0, 1000, 10));
            s.add(SettingSpec.toggle("自动切换工具", true));
            return s;
        }

        if (n.equals("玩家透视") || n.equals("生物透视") || n.equals("箱子透视") ||
                n.equals("方块透视") || n.equals("ESP线框") || n.equals("ESP名称") ||
                n.equals("ESP距离") || n.equals("ESP物品") || n.equals("追踪射线")) {
            s.add(SettingSpec.slider("显示范围", 64, 8, 256, 1));
            s.add(SettingSpec.toggle("显示标签", true));
            return s;
        }

        if (n.equals("FOV调整")) {
            s.add(SettingSpec.slider("FOV", 90, 30, 170, 1));
            return s;
        }

        if (n.equals("视角缩放")) {
            s.add(SettingSpec.slider("缩放倍率", 2.0, 1, 10, 0.1));
            return s;
        }

        // Special requested module.
        if (n.equals("自动找附魔金")) {
            s.add(SettingSpec.slider("扫描半径", 5000, 500, 10000, 100));
            s.add(SettingSpec.slider("古城扫描范围", 200, 32, 512, 8));
            s.add(SettingSpec.slider("扫描间隔", 5, 1, 60, 1));
            s.add(SettingSpec.slider("最大目标数量", 10, 1, 50, 1));
            s.add(SettingSpec.toggle("需要鞘翅", true));
            s.add(SettingSpec.toggle("液体安全检查", true));
            s.add(SettingSpec.toggle("直线下挖", true));
            s.add(SettingSpec.toggle("返回原路", true));
            s.add(SettingSpec.toggle("只获取附魔金", true));
            s.add(SettingSpec.toggle("无烟花鞘翅飞行", true));
            s.add(SettingSpec.toggle("长按空格升高", true));
            s.add(SettingSpec.toggle("下蹲下降搜索", true));
            s.add(SettingSpec.toggle("返回原挖掘位置", true));
            s.add(SettingSpec.toggle("直线上升出古城", true));
            s.add(SettingSpec.slider("目标上方高度", 12, 3, 40, 1));
            s.add(SettingSpec.mode("飞行方式", "甲飞", "甲飞", "普通鞘翅"));
            s.add(SettingSpec.mode("甲飞控制模式", "TICK", "LAZY", "TICK_LEGACY", "TICK"));
            s.add(SettingSpec.toggle("禁止烟花推进", true));
            s.add(SettingSpec.mode("路线模式", "最近优先", "最近优先", "最短路线", "目标密度"));
            return s;
        }

        if (n.equals("自动补充镐子")) {
            s.add(SettingSpec.slider("触发耐久百分比", 10, 1, 50, 1));
            s.add(SettingSpec.slider("备用镐最低耐久百分比", 95, 50, 100, 1));
            s.add(SettingSpec.slider("操作间隔", 5, 1, 40, 1));
            s.add(SettingSpec.toggle("自动寻找末影箱", true));
            s.add(SettingSpec.toggle("只取镐子", true));
            s.add(SettingSpec.toggle("归还潜影盒", true));
            s.add(SettingSpec.toggle("预留背包空位", true));
            s.add(SettingSpec.toggle("找不到备用镐时通知", true));
            return s;
        }

        if (n.equals("自动补充烟花")) {
            s.add(SettingSpec.slider("触发数量", 100, 0, 576, 1));
            s.add(SettingSpec.slider("补充目标", 256, 64, 576, 64));
            s.add(SettingSpec.slider("预留背包空位", 1, 1, 5, 1));
            s.add(SettingSpec.slider("操作间隔", 5, 1, 40, 1));
            s.add(SettingSpec.toggle("自动寻找末影箱", true));
            s.add(SettingSpec.toggle("只使用含烟花的潜影盒", true));
            s.add(SettingSpec.toggle("归还潜影盒", true));
            s.add(SettingSpec.toggle("找不到材料时通知", true));
            return s;
        }

        if (n.equals("自动补充镐子")) {
            s.add(SettingSpec.slider("触发耐久百分比", 10, 1, 50, 1));
            s.add(SettingSpec.slider("备用镐最低耐久百分比", 95, 50, 100, 1));
            s.add(SettingSpec.slider("操作间隔", 5, 1, 40, 1));
            s.add(SettingSpec.toggle("自动寻找末影箱", true));
            s.add(SettingSpec.toggle("只取镐子", true));
            s.add(SettingSpec.toggle("归还潜影盒", true));
            s.add(SettingSpec.toggle("预留背包空位", true));
            s.add(SettingSpec.toggle("找不到备用镐时通知", true));
            return s;
        }

        // Generic UI values for modules that have no dedicated public setting schema.
        switch (module.category()) {
            case COMBAT -> {
                s.add(SettingSpec.slider("范围", 4.5, 1, 10, 0.1));
                s.add(SettingSpec.slider("延迟", 100, 0, 1000, 10));
            }
            case MOVEMENT -> {
                s.add(SettingSpec.slider("速度", 1.0, 0.1, 5.0, 0.1));
                s.add(SettingSpec.toggle("自动模式", true));
            }
            case WORLD -> {
                s.add(SettingSpec.slider("范围", 32, 4, 256, 1));
                s.add(SettingSpec.slider("延迟", 100, 0, 1000, 10));
            }
            case RENDER -> {
                s.add(SettingSpec.slider("显示范围", 64, 8, 256, 1));
                s.add(SettingSpec.toggle("显示标签", true));
            }
            case MISC, CONFIG, GENERATOR -> {
                s.add(SettingSpec.slider("延迟", 100, 0, 2000, 10));
                s.add(SettingSpec.toggle("通知", true));
            }
        }
        return s;
    }
}
