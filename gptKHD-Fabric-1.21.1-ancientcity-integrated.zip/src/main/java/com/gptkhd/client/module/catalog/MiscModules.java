package com.gptkhd.client.module.catalog;

import com.gptkhd.client.module.ModuleCategory;
import com.gptkhd.client.module.ModuleSpec;
import java.util.List;

public final class MiscModules {
    private MiscModules() {}

    public static List<ModuleSpec> all() {
        return List.of(
            new ModuleSpec("自动登录", ModuleCategory.MISC, "自动登录 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("防卡顿", ModuleCategory.MISC, "防卡顿 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("自动重连", ModuleCategory.MISC, "自动重连 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("聊天管理", ModuleCategory.MISC, "聊天管理 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("假聊天", ModuleCategory.MISC, "假聊天 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("自动回复", ModuleCategory.MISC, "自动回复 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("指令快捷键", ModuleCategory.MISC, "指令快捷键 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("防追踪", ModuleCategory.MISC, "防追踪 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("反作弊检测", ModuleCategory.MISC, "反作弊检测 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("延迟优化", ModuleCategory.MISC, "延迟优化 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("便捷功能", ModuleCategory.MISC, "便捷功能 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("音乐播放器", ModuleCategory.MISC, "音乐播放器 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("皮肤更换", ModuleCategory.MISC, "皮肤更换 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("自定义命令", ModuleCategory.MISC, "自定义命令 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("多开管理", ModuleCategory.MISC, "多开管理 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("实验性功能", ModuleCategory.MISC, "实验性功能 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("开发者模式", ModuleCategory.MISC, "开发者模式 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("语言设置", ModuleCategory.MISC, "语言设置 模块", List.of("启用", "按键", "显示通知"))
        );
    }
}
