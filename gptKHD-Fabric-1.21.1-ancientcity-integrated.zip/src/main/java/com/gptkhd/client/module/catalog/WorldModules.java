package com.gptkhd.client.module.catalog;

import com.gptkhd.client.module.ModuleCategory;
import com.gptkhd.client.module.ModuleSpec;
import java.util.List;

public final class WorldModules {
    private WorldModules() {}

    public static List<ModuleSpec> all() {
        return List.of(
            new ModuleSpec("X射线", ModuleCategory.WORLD, "X射线 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("全亮", ModuleCategory.WORLD, "全亮 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("时间修改", ModuleCategory.WORLD, "时间修改 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("天气控制", ModuleCategory.WORLD, "天气控制 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("自动挖矿", ModuleCategory.WORLD, "自动挖矿 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("快速挖掘", ModuleCategory.WORLD, "快速挖掘 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("方块透视", ModuleCategory.WORLD, "方块透视 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("生物透视", ModuleCategory.WORLD, "生物透视 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("掉落物透视", ModuleCategory.WORLD, "掉落物透视 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("宝箱透视", ModuleCategory.WORLD, "宝箱透视 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("古城追踪", ModuleCategory.WORLD, "古城追踪 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("要塞追踪", ModuleCategory.WORLD, "要塞追踪 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("矿洞追踪", ModuleCategory.WORLD, "矿洞追踪 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("地形标记", ModuleCategory.WORLD, "地形标记 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("液体检测", ModuleCategory.WORLD, "液体检测 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("防止掉落", ModuleCategory.WORLD, "防止掉落 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("自动放置", ModuleCategory.WORLD, "自动放置 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("自动采集", ModuleCategory.WORLD, "自动采集 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("自动合成", ModuleCategory.WORLD, "自动合成 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("物品过滤", ModuleCategory.WORLD, "物品过滤 模块", List.of("启用", "按键", "显示通知"))
        );
    }
}
