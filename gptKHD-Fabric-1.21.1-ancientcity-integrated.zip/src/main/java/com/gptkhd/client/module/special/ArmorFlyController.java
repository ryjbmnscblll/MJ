package com.gptkhd.client.module.special;

/**
 * 甲飞控制抽象层。
 *
 * 参考已提供客户端中的 ElytraExtra / ElytraFlight 行为设计：
 * - 甲飞优先于烟花推进；
 * - 起飞后保持滑翔状态；
 * - 可用 Tick/Lazy 两类控制策略；
 * - 落地/进入目标区域时允许安全收尾。
 *
 * 这里不复制第三方字节码，也不实现反作弊绕过逻辑；真正的按键、姿态和
 * 玩家实体控制由 Fabric 1.21.1 适配层实现。
 */
public final class ArmorFlyController {
    public enum Mode {
        LAZY,
        TICK_LEGACY,
        TICK
    }

    private Mode mode = Mode.TICK;
    private boolean active;
    private boolean holdingJump;
    private boolean sneaking;

    public void setMode(Mode mode) {
        this.mode = mode == null ? Mode.TICK : mode;
    }

    public Mode mode() {
        return mode;
    }

    public void startGlide() {
        active = true;
    }

    public void stopGlide() {
        active = false;
        holdingJump = false;
        sneaking = false;
    }

    public void holdJump(boolean value) {
        holdingJump = value;
        if (value) sneaking = false;
    }

    public void sneakDown(boolean value) {
        sneaking = value;
        if (value) holdingJump = false;
    }

    public boolean active() { return active; }
    public boolean holdingJump() { return holdingJump; }
    public boolean sneaking() { return sneaking; }

    /** 当前任务阶段是否允许继续使用甲飞控制。 */
    public boolean canContinue(boolean hasElytra, boolean inLiquid, boolean onGround) {
        if (!active || !hasElytra) return false;
        if (onGround) return false;
        return !inLiquid;
    }
}
