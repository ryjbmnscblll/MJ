package com.gptkhd.client.module;

import com.gptkhd.client.setting.Setting;
import java.util.ArrayList;
import java.util.List;

public class Module {
    private final String name;
    private final String description;
    private final ModuleCategory category;
    private final List<Setting<?>> settings = new ArrayList<>();
    private boolean enabled;

    public Module(String name, ModuleCategory category, String description) {
        this.name = name;
        this.category = category;
        this.description = description;
    }

    public void setEnabled(boolean enabled) {
        if (this.enabled == enabled) return;
        this.enabled = enabled;
        if (enabled) onEnable();
        else onDisable();
    }

    public void toggle() {
        setEnabled(!enabled);
    }

    protected void onEnable() {}
    protected void onDisable() {}
    public void onTick() {}

    protected final <T extends Setting<?>> T add(T setting) {
        settings.add(setting);
        return setting;
    }

    public String name() { return name; }
    public String description() { return description; }
    public ModuleCategory category() { return category; }
    public boolean enabled() { return enabled; }
    public List<Setting<?>> settings() { return List.copyOf(settings); }
}
