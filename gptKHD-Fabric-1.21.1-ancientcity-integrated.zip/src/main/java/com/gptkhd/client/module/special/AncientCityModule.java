package com.gptkhd.client.module.special;

import com.gptkhd.client.module.Module;
import com.gptkhd.client.module.ModuleCategory;
import com.gptkhd.client.setting.BooleanSetting;
import com.gptkhd.client.setting.ModeSetting;
import com.gptkhd.client.setting.NumberSetting;
import java.util.List;

/** StructureFinder-derived Ancient City task controller for gptKHD Fabric 1.21.1. */
public final class AncientCityModule extends Module {
    public enum State {
        空闲, 读取Seed, 定位古城, 预测附魔金箱, 前往古城, 甲飞下降,
        目标上升, 目标定位, 下蹲搜索, 开箱取物, 前往下一箱,
        古城完成, 返回入口, 直线上升, 前往下一古城, 完成, 暂停
    }

    public final NumberSetting scanRadius = add(new NumberSetting("古城扫描半径", 5000, 500, 10000, 100));
    public final NumberSetting maxCities = add(new NumberSetting("最大古城数量", 20, 1, 100, 1));
    public final NumberSetting cityChestRadius = add(new NumberSetting("箱子搜索范围", 200, 32, 512, 8));
    public final BooleanSetting preciseApplePrediction = add(new BooleanSetting("精确预测附魔金箱", true));
    public final BooleanSetting verifyLoadedChest = add(new BooleanSetting("加载后验证箱子", true));

    public final ModeSetting flightMode = add(new ModeSetting("古城飞行方式", "甲飞", List.of("甲飞", "普通鞘翅")));
    public final ModeSetting armorFlyMode = add(new ModeSetting("甲飞控制模式", "TICK", List.of("LAZY", "TICK_LEGACY", "TICK")));
    public final BooleanSetting noFirework = add(new BooleanSetting("禁止主动烟花", true));
    public final BooleanSetting holdJump = add(new BooleanSetting("空格升高", true));
    public final BooleanSetting crouchDown = add(new BooleanSetting("下蹲下降", true));
    public final NumberSetting targetHeight = add(new NumberSetting("目标上方高度", 12, 3, 40, 1));
    public final BooleanSetting returnToEntry = add(new BooleanSetting("返回原挖掘入口", true));
    public final BooleanSetting verticalExit = add(new BooleanSetting("直线上升离开", true));

    public final BooleanSetting autoFireworkRefill = add(new BooleanSetting("自动补充烟花", true));
    public final NumberSetting fireworkThreshold = add(new NumberSetting("烟花触发数量", 100, 1, 1024, 1));
    public final NumberSetting fireworkTarget = add(new NumberSetting("烟花补充目标", 256, 16, 2304, 16));
    public final NumberSetting reservedBoxSlot = add(new NumberSetting("预留潜影盒位置", 1, 1, 9, 1));

    public final BooleanSetting autoPickaxeRefill = add(new BooleanSetting("自动补充镐子", true));
    public final NumberSetting pickaxeDurability = add(new NumberSetting("镐子触发耐久%", 10, 1, 50, 1));
    public final NumberSetting replacementDurability = add(new NumberSetting("备用镐最低耐久%", 95, 50, 100, 1));

    public final BooleanSetting liquidSafety = add(new BooleanSetting("液体安全检查", true));
    public final BooleanSetting onlyEnchantedGoldenApple = add(new BooleanSetting("只获取附魔金", true));

    private State state = State.空闲;
    private final ArmorFlyController armorFly = new ArmorFlyController();
    private final AutoFireworkRefill fireworkRefill = new AutoFireworkRefill();
    private final AutoPickaxeRefill pickaxeRefill = new AutoPickaxeRefill();
    private final StructureFinderAncientCityScanner cityScanner = new StructureFinderAncientCityScanner();
    private final LoadedEnchantedGoldChestLocator chestLocator = new LoadedEnchantedGoldChestLocator();
    private List<StructureFinderAncientCityScanner.City> cities = List.of();
    private List<LoadedEnchantedGoldChestLocator.ChestTarget> chests = List.of();

    public AncientCityModule() {
        super("古城", ModuleCategory.GENERATOR, "StructureFinder 古城定位 + 附魔金箱预测 + 甲飞任务控制");
    }

    @Override protected void onEnable() {
        state = State.读取Seed;
        armorFly.setMode(parseMode(armorFlyMode.get()));
        if (autoFireworkRefill.get()) fireworkRefill.start();
        if (autoPickaxeRefill.get()) pickaxeRefill.start();
    }

    @Override protected void onDisable() {
        state = State.空闲;
        armorFly.stopGlide();
        fireworkRefill.stop();
        pickaxeRefill.stop();
    }

    public State state() { return state; }
    public List<StructureFinderAncientCityScanner.City> cities() { return List.copyOf(cities); }
    public List<LoadedEnchantedGoldChestLocator.ChestTarget> chests() { return List.copyOf(chests); }
    public ArmorFlyController armorFly() { return armorFly; }
    public AutoFireworkRefill fireworkRefill() { return fireworkRefill; }
    public AutoPickaxeRefill pickaxeRefill() { return pickaxeRefill; }

    public List<StructureFinderAncientCityScanner.City> locateCities(long seed, int playerX, int playerZ) {
        cities = cityScanner.findNearest(seed, playerX, playerZ, (int) scanRadius.get(), (int) maxCities.get());
        state = State.定位古城;
        return cities;
    }

    public List<LoadedEnchantedGoldChestLocator.ChestTarget> verifyLoadedChests(
            net.minecraft.client.world.ClientWorld world, int cityX, int cityZ) {
        chests = chestLocator.scan(world, cityX, cityZ, (int) cityChestRadius.get());
        state = chests.isEmpty() ? State.前往古城 : State.目标定位;
        return chests;
    }

    public void advance(boolean seedReady, boolean cityReady, boolean targetAbove,
                        boolean targetFound, boolean looted, boolean nextTarget,
                        boolean cityFinished, boolean entryReached, boolean exitReached,
                        boolean allFinished, boolean safeToFly) {
        armorFly.setMode(parseMode(armorFlyMode.get()));
        if (!safeToFly && state != State.空闲 && state != State.完成) {
            state = State.暂停;
            armorFly.stopGlide();
            return;
        }
        switch (state) {
            case 读取Seed -> { if (seedReady) state = State.定位古城; }
            case 定位古城 -> { if (cityReady) state = State.预测附魔金箱; }
            case 预测附魔金箱 -> state = cities.isEmpty() ? State.完成 : State.前往古城;
            case 前往古城 -> { if (cityReady) { armorFly.startGlide(); state = State.甲飞下降; } }
            case 甲飞下降 -> {
                if (noFirework.get()) fireworkRefill.suppressBoost();
                armorFly.holdJump(false);
                if (targetAbove) state = State.目标上升;
            }
            case 目标上升 -> {
                armorFly.holdJump(holdJump.get());
                if (targetAbove) { armorFly.holdJump(false); state = State.目标定位; }
            }
            case 目标定位 -> { if (targetFound) state = State.下蹲搜索; }
            case 下蹲搜索 -> {
                armorFly.sneakDown(crouchDown.get());
                if (targetFound) { armorFly.sneakDown(false); state = State.开箱取物; }
            }
            case 开箱取物 -> {
                if (autoFireworkRefill.get()) fireworkRefill.tick();
                if (autoPickaxeRefill.get()) pickaxeRefill.tick();
                if (looted) state = nextTarget ? State.前往下一箱 : State.古城完成;
            }
            case 前往下一箱 -> { armorFly.startGlide(); state = State.目标定位; }
            case 古城完成 -> state = returnToEntry.get() ? State.返回入口 : State.前往下一古城;
            case 返回入口 -> { if (entryReached) state = verticalExit.get() ? State.直线上升 : State.前往下一古城; }
            case 直线上升 -> {
                armorFly.holdJump(true);
                if (exitReached) { armorFly.holdJump(false); state = State.前往下一古城; }
            }
            case 前往下一古城 -> state = allFinished ? State.完成 : State.定位古城;
            case 暂停 -> { if (safeToFly) state = State.甲飞下降; }
            case 完成 -> armorFly.stopGlide();
            case 空闲 -> {}
        }
    }

    private ArmorFlyController.Mode parseMode(String value) {
        try { return ArmorFlyController.Mode.valueOf(value); }
        catch (Exception e) { return ArmorFlyController.Mode.TICK; }
    }
}
