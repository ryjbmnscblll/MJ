package com.gptkhd.client.module.catalog;

import com.gptkhd.client.module.ModuleCategory;
import com.gptkhd.client.module.ModuleSpec;
import java.util.List;

public final class MovementModules {
    private MovementModules() {}

    public static List<ModuleSpec> all() {
        return List.of(
            new ModuleSpec("飞行", ModuleCategory.MOVEMENT, "飞行 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("速度", ModuleCategory.MOVEMENT, "速度 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("跳跃增强", ModuleCategory.MOVEMENT, "跳跃增强 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("无重力", ModuleCategory.MOVEMENT, "无重力 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("长跳", ModuleCategory.MOVEMENT, "长跳 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("自动行走", ModuleCategory.MOVEMENT, "自动行走 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("自动跳跃", ModuleCategory.MOVEMENT, "自动跳跃 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("空中控制", ModuleCategory.MOVEMENT, "空中控制 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("伪装蹲下", ModuleCategory.MOVEMENT, "伪装蹲下 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("无限耐力", ModuleCategory.MOVEMENT, "无限耐力 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("水上行走", ModuleCategory.MOVEMENT, "水上行走 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("水下呼吸", ModuleCategory.MOVEMENT, "水下呼吸 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("缓降", ModuleCategory.MOVEMENT, "缓降 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("滑翔（鞘翅）", ModuleCategory.MOVEMENT, "滑翔（鞘翅） 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("自动鞘翅", ModuleCategory.MOVEMENT, "自动鞘翅 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("自动梯子", ModuleCategory.MOVEMENT, "自动梯子 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("避开障碍", ModuleCategory.MOVEMENT, "避开障碍 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("传送", ModuleCategory.MOVEMENT, "传送 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("瞬移", ModuleCategory.MOVEMENT, "瞬移 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("回到上一个位置", ModuleCategory.MOVEMENT, "回到上一个位置 模块", List.of("启用", "按键", "显示通知"))
        );
    }
}
