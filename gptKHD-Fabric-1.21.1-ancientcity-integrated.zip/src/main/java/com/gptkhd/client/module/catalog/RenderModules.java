package com.gptkhd.client.module.catalog;

import com.gptkhd.client.module.ModuleCategory;
import com.gptkhd.client.module.ModuleSpec;
import java.util.List;

public final class RenderModules {
    private RenderModules() {}

    public static List<ModuleSpec> all() {
        return List.of(
            new ModuleSpec("玩家透视", ModuleCategory.RENDER, "玩家透视 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("生物透视", ModuleCategory.RENDER, "生物透视 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("箱子透视", ModuleCategory.RENDER, "箱子透视 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("方块透视", ModuleCategory.RENDER, "方块透视 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("光影增强", ModuleCategory.RENDER, "光影增强 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("夜视", ModuleCategory.RENDER, "夜视 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("高亮显示", ModuleCategory.RENDER, "高亮显示 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("ESP线框", ModuleCategory.RENDER, "ESP线框 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("ESP骨骼", ModuleCategory.RENDER, "ESP骨骼 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("ESP名称", ModuleCategory.RENDER, "ESP名称 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("ESP距离", ModuleCategory.RENDER, "ESP距离 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("ESP物品", ModuleCategory.RENDER, "ESP物品 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("追踪射线", ModuleCategory.RENDER, "追踪射线 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("视角缩放", ModuleCategory.RENDER, "视角缩放 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("FOV调整", ModuleCategory.RENDER, "FOV调整 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("无雾", ModuleCategory.RENDER, "无雾 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("无水", ModuleCategory.RENDER, "无水 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("动态光源", ModuleCategory.RENDER, "动态光源 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("屏幕亮度", ModuleCategory.RENDER, "屏幕亮度 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("HUD隐藏", ModuleCategory.RENDER, "HUD隐藏 模块", List.of("启用", "按键", "显示通知"))
        );
    }
}
