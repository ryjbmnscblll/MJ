package com.gptkhd.client.module.special;

import de.rasmusantons.cubiomes.Cubiomes;
import de.rasmusantons.cubiomes.Dimension;
import de.rasmusantons.cubiomes.MCVersion;
import de.rasmusantons.cubiomes.Pos;
import de.rasmusantons.cubiomes.StructureType;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * StructureFinder-derived structure search core for gptKHD.
 *
 * It replaces the old placeholder "scan 5000 blocks" logic with the same
 * seed/region based Ancient City lookup strategy: Minecraft 1.21.1 seed ->
 * structure placement -> viability check -> nearest candidates.
 *
 * This class intentionally does not copy Meteor's module/event code. It only
 * exposes the structure-finding part needed by gptKHD.
 */
public final class StructureFinderAncientCityScanner {
    public record City(int x, int z, long distanceSquared) {}

    private final Cubiomes cubiomes;

    public StructureFinderAncientCityScanner() {
        cubiomes = new Cubiomes(MCVersion.MC_1_21_1);
    }

    public List<City> findNearest(long seed, int centerX, int centerZ, int radius, int maxResults) {
        cubiomes.applySeed(Dimension.DIM_OVERWORLD, seed);

        int minRegionX = Math.floorDiv(centerX - radius, 384) - 1;
        int maxRegionX = Math.floorDiv(centerX + radius, 384) + 1;
        int minRegionZ = Math.floorDiv(centerZ - radius, 384) - 1;
        int maxRegionZ = Math.floorDiv(centerZ + radius, 384) + 1;
        long radiusSq = (long) radius * radius;

        ArrayList<City> result = new ArrayList<>(Math.max(1, maxResults));
        for (int rx = minRegionX; rx <= maxRegionX; rx++) {
            for (int rz = minRegionZ; rz <= maxRegionZ; rz++) {
                Pos pos = cubiomes.getStructurePos(StructureType.Ancient_City, seed, rx, rz);
                long dx = (long) pos.x() - centerX;
                long dz = (long) pos.z() - centerZ;
                long distSq = dx * dx + dz * dz;
                if (distSq > radiusSq) continue;
                if (!cubiomes.isViableStructurePos(StructureType.Ancient_City, pos.x(), pos.z())) continue;

                result.add(new City(pos.x(), pos.z(), distSq));
            }
        }

        result.sort(Comparator.comparingLong(City::distanceSquared));
        if (result.size() > maxResults) return List.copyOf(result.subList(0, maxResults));
        return List.copyOf(result);
    }
}
