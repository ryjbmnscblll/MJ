package com.gptkhd.client.module;

import com.gptkhd.client.setting.SettingSpec;
import java.util.List;

public record ModuleSpec(
        String name,
        ModuleCategory category,
        String description,
        List<String> defaultSettings
) {
    public List<SettingSpec> adjustableSettings() {
        return ModuleSettingsCatalog.settings(this);
    }
}
