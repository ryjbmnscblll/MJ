package com.gptkhd.client.module.special;

/**
 * 自动补充烟花的工作流状态。
 *
 * 设计目标：当玩家烟花数量低于/等于触发阈值时，寻找背包里的末影箱，
 * 从末影箱中找到装有烟花的潜影盒，取出烟花，并在末影箱中保留空位以
 * 便把潜影盒归还。实际服务器容器点击/移动由 1.21.1 的客户端适配层执行。
 */
public final class AutoFireworkRefill {
    public enum State {
        空闲,
        检查烟花数量,
        寻找末影箱,
        打开末影箱,
        寻找烟花潜影盒,
        预留空位,
        取出潜影盒,
        补充烟花,
        归还潜影盒,
        完成,
        缺少末影箱,
        缺少烟花潜影盒,
        无法归还潜影盒
    }

    private int triggerCount = 100;
    private int targetCount = 256;
    private int reservedSlots = 1;
    private State state = State.空闲;
    private int lastFireworkCount;

    public void setTriggerCount(int value) { triggerCount = Math.max(0, value); }
    public void setTargetCount(int value) { targetCount = Math.max(triggerCount, value); }
    public void setReservedSlots(int value) { reservedSlots = Math.max(1, value); }

    public void tick(int fireworksInInventory) {
        lastFireworkCount = fireworksInInventory;
        if (state == State.完成 || state == State.空闲) {
            if (fireworksInInventory <= triggerCount) state = State.检查烟花数量;
            else state = State.空闲;
            return;
        }
        // The concrete inventory/container adapter advances the remaining states.
    }

    public boolean shouldRefill() { return lastFireworkCount <= triggerCount; }
    public int targetCount() { return targetCount; }
    public int reservedSlots() { return reservedSlots; }
    public State state() { return state; }
    public void setState(State state) { this.state = state == null ? State.空闲 : state; }
}
