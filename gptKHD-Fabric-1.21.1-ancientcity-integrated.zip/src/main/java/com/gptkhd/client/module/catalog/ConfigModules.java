package com.gptkhd.client.module.catalog;

import com.gptkhd.client.module.ModuleCategory;
import com.gptkhd.client.module.ModuleSpec;
import java.util.List;

public final class ConfigModules {
    private ConfigModules() {}

    public static List<ModuleSpec> all() {
        return List.of(
            new ModuleSpec("保存配置", ModuleCategory.CONFIG, "保存配置 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("读取配置", ModuleCategory.CONFIG, "读取配置 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("管理配置", ModuleCategory.CONFIG, "管理配置 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("导出配置", ModuleCategory.CONFIG, "导出配置 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("导入配置", ModuleCategory.CONFIG, "导入配置 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("重置配置", ModuleCategory.CONFIG, "重置配置 模块", List.of("启用", "按键", "显示通知"))
        );
    }
}
