package com.gptkhd.client.module.catalog;

import com.gptkhd.client.module.ModuleCategory;
import com.gptkhd.client.module.ModuleSpec;
import java.util.List;

public final class CombatModules {
    private CombatModules() {}

    public static List<ModuleSpec> all() {
        return List.of(
            new ModuleSpec("水晶光环", ModuleCategory.COMBAT, "水晶光环 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("杀戮光环", ModuleCategory.COMBAT, "杀戮光环 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("长矛光环", ModuleCategory.COMBAT, "长矛光环 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("自动攻击", ModuleCategory.COMBAT, "自动攻击 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("自动使用物品", ModuleCategory.COMBAT, "自动使用物品 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("攻击辅助", ModuleCategory.COMBAT, "攻击辅助 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("目标选择", ModuleCategory.COMBAT, "目标选择 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("范围攻击", ModuleCategory.COMBAT, "范围攻击 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("近战范围", ModuleCategory.COMBAT, "近战范围 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("攻击速度", ModuleCategory.COMBAT, "攻击速度 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("穿透攻击", ModuleCategory.COMBAT, "穿透攻击 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("击退控制", ModuleCategory.COMBAT, "击退控制 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("自动连击", ModuleCategory.COMBAT, "自动连击 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("自动格挡", ModuleCategory.COMBAT, "自动格挡 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("暴击辅助", ModuleCategory.COMBAT, "暴击辅助 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("自动钓鱼", ModuleCategory.COMBAT, "自动钓鱼 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("定位打击", ModuleCategory.COMBAT, "定位打击 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("盾牌辅助", ModuleCategory.COMBAT, "盾牌辅助 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("范围伤害", ModuleCategory.COMBAT, "范围伤害 模块", List.of("启用", "按键", "显示通知")),
    new ModuleSpec("触发器", ModuleCategory.COMBAT, "触发器 模块", List.of("启用", "按键", "显示通知"))
        );
    }
}
