package com.gptkhd.client.module.catalog;

import com.gptkhd.client.module.ModuleCategory;
import com.gptkhd.client.module.ModuleSpec;
import java.util.List;

public final class GeneratorModules {
    private GeneratorModules() {}

    public static List<ModuleSpec> all() {
        return List.of(
            new ModuleSpec("古城", ModuleCategory.GENERATOR, "StructureFinder 古城定位与附魔金任务总控", List.of("启用", "按键", "显示通知")),
            new ModuleSpec("自动找附魔金", ModuleCategory.GENERATOR, "自动找附魔金 模块", List.of("启用", "按键", "显示通知")),
            new ModuleSpec("自动补充烟花", ModuleCategory.GENERATOR, "烟花数量不足时，从末影箱中的烟花潜影盒补充", List.of("启用", "按键", "显示通知")),
            new ModuleSpec("自动补充镐子", ModuleCategory.GENERATOR, "镐子耐久不足时，从末影箱中的潜影盒更换高耐久镐子", List.of("启用", "按键", "显示通知"))
        );
    }
}
