# StructureFinder integration

The previous placeholder Ancient City scan has been replaced by a seed/region structure finder adapter based on the uploaded StructureFinder JAR's Cubiomes-based lookup strategy.

## What was integrated

- Minecraft 1.21.1 Cubiomes structure core (`MC_1_21_1`)
- Overworld seed application
- 384-block Ancient City region lookup
- Ancient City viability check
- nearest-city sorting and radius filtering
- a real loaded-world chest verifier for `ENCHANTED_GOLDEN_APPLE`

## Important distinction

The uploaded addon is a Meteor addon and cannot be dropped into a Fabric-only gptKHD project as-is. Its Meteor event/module classes were not copied into gptKHD. Instead, the structure-finding portion was isolated into a small local `gptKHD-cubiomes-core.jar`, while gptKHD owns the Minecraft/Fabric-facing code.

The chest verifier checks actual loaded chest inventories. This avoids treating a seed prediction as proof that a chest is currently loaded or contains the item.

## Files

- `StructureFinderAncientCityScanner.java`
- `LoadedEnchantedGoldChestLocator.java`
- `AutoEnchantedGold.java` now calls the new scanner/locator instead of relying only on the old placeholder state.
- `libs/gptKHD-cubiomes-core.jar`
